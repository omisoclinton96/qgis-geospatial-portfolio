# QGIS Geospatial Portfolio

This portfolio showcases QGIS-based geospatial analysis projects, including public health mapping, spatial data visualization, and GIS-driven decision support systems.

## Featured Projects
1. Health Facility Mapping and Accessibility Analysis — Kenya
2. Geospatial Tracking of Participants — OCV Trial
3. Spatial Hotspot Analysis for Disease Risk Identification
4. Geospatial Visualization of Field Operations and Sample Flow

## Publish with GitHub Pages
1. Create a public GitHub repository named `qgis-geospatial-portfolio`
2. Upload the contents of this folder
3. Go to **Settings > Pages**
4. Under **Source**, choose **Deploy from a branch**
5. Select `main` and `/root`
6. Save and wait for the public link

Your site will appear as:
`https://yourusername.github.io/qgis-geospatial-portfolio/`

## Before Publishing
- Replace placeholder screenshots with your own QGIS exports
- Update your name, email, and GitHub link in `index.html`
- Tailor the project descriptions to match your actual work
