# QGIS Geospatial Analysis Portfolio Website

This package gives you a ready-to-edit geospatial portfolio website for Handshake or other job applications.

## Files included
- `index.html` – the main website page
- `style.css` – styles and layout
- `script.js` – light animation
- `assets/` – placeholder project images

## How to customize
1. Open `index.html` in any text editor.
2. Replace **Bonface Osindi** with your preferred professional name.
3. Update the About section and project descriptions to match your exact work.
4. Replace placeholder images in `assets/` with exported screenshots from QGIS.
5. Update the contact section with your real email, GitHub, and LinkedIn.

## How to publish on GitHub Pages
1. Create a GitHub repository, for example: `qgis-geospatial-portfolio`
2. Upload all files from this folder.
3. In GitHub, go to **Settings > Pages**.
4. Under **Build and deployment**, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
5. Save.
6. GitHub will generate a website link that looks like:
   `https://yourusername.github.io/qgis-geospatial-portfolio/`

That GitHub Pages URL is the best link to paste into Handshake.

## What to include in your final version
- 3 to 5 strong QGIS project screenshots
- A short explanation of the spatial problem
- What data/layers you used
- What analysis you performed
- The insight or decision the map supported

## Suggested real project titles
- Health Facility Distribution and Service Coverage Mapping
- Disease Surveillance Hotspot Analysis
- Field Operations and Sample Logistics Mapping
- Community Resource Accessibility Mapping
- Administrative Boundary and Population Overlay Analysis

## Optional add-ons
- Add a downloadable PDF resume
- Add a GitHub link to your code or map files
- Add a short case study page for each project
