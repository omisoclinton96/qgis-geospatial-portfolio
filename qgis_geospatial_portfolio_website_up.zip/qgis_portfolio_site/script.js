const revealItems = document.querySelectorAll('.project-card, .skill-box, .stat-card, .checklist div');
revealItems.forEach((el) => el.classList.add('reveal'));

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

revealItems.forEach((el) => observer.observe(el));
